package com.mercadolibre.romannumerals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RomanNumeralsApplication {

  public static void main(String[] args) {
    SpringApplication.run(RomanNumeralsApplication.class, args);
  }

}
